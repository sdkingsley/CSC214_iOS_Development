Sarah Kingsley
skingsl2@u.rochester.edu
Project 2
CSC 214
Nov 28, 2016

See PDF for in depth explanation of app.

I would like the use of extensive use of segue data transfer and intitial forages in to design for the main app to be considered for extra credit.

Also because my fulfillment of some of the requirements are more subtle I’d like to explain that here.

A) It does have a launch screen & Launcher Icon, and the app is localized for the French Language.

B) Every screen uses buttons to navigate between views.

C) The tertiary screen with the image fills these requirements but will not be in the final version of the app, the picture in this screen is persistant
    i) The image serves as model data entered by the user
    ii) Users can choose from the camera roll and it is saved with ImageHelper
    iii) Users can take a picture and it is saved with ImageHelper

D) Stackviews are implimented for the main page of the app

In future iterations I would like to look in to making custom data types persistant, some of that initial code is in this version but is not used when testing the app.

I affirm that I will not give or receive any unauthorized help on this assignment, and that this work is my own.
