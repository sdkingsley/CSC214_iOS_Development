Sarah Kingsley
skingsl2@u.rochester.edu
Assignment 8
CSC 214
Nov 6, 2016

This application uses navigation controllers, stack views, and transfers information between views. It has four textviews on the first page and those transfer back and forth with data from the second page.

It was working perfectly before completing the final steps of the navigation bar. I commented out the code that doesn’t work anymore so you can see it for partial credit.

I affirm that I will not give or receive any unauthorized help on this assignment, and that this work is my own.