Sarah Kingsley
skingsl2@u.rochester.edu
Assignment 9
CSC 214
Nov 16, 2016

Assignment 9 was an exercise in using the camera. This app utilizes key functionalities such as a UI Toolbar, bar button items, accessing the photo library, accessing the phone’s camera, an image view and buttons that adjust the image from aspect fit to scale to fit, a textfield where the user can enter a caption, and persistent handling of both the image and the caption.

I would like extra credit for my text view handling utilizing the delegate so that the return button on the keyboard hide’s the keyboard.

I affirm that I will not give or receive any unauthorized help on this assignment, and that this work is my own.