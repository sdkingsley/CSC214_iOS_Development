Sarah Kingsley
skingsl2@u.rochester.edu
Project 1
CSC 214
Nov 6, 2016

See PDF for in depth explanation of app.

I would like the use of MFMessageComposeViewControllerDelegate to be considered for extra credit.

Also because my fulfillment of some of the requirements are more subtle I’d like to explain that here.

It does have a launch screen & Launcher Icon, and the app is localized for the French Language
It does work with double length pseudo language, as is shown in the screenshots included
Tab bar with custom icons
The second tab contains a table view with editable entries that can move, delete and get added to.
When the first tab appears the label uses an opacity to fade in, additionally the label jumps and the background color turns gray when the user taps to signify that their action wasn’t effective and they need to implement a long press
The text fields are implemented to add user specified data to the table view, the text view delegate was used to limit the number text view to 10 numbers so that the user cannot exceed what is understood by the messenger delegate

I affirm that I will not give or receive any unauthorized help on this assignment, and that this work is my own.